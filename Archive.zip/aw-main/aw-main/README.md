---
title: Text To Music
emoji: ⚡
colorFrom: red
colorTo: green
sdk: gradio
sdk_version: 3.6
app_file: app.py
pinned: false
license: unknown
duplicated_from: Mubert/Text-to-Music
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
