---
title: Riffusion App
emoji: 🎶
colorFrom: purple
colorTo: purple
sdk: docker
pinned: false
---
