---
license: mit
library_name: keras
tags:
- audio
- music
- generation
- tensorflow
---

# Musika Techno Model

Pretrained Techno GAN model for the [Musika system](https://github.com/marcoppasini/musika) for fast infinite waveform music generation.
Introduced in [this paper](https://arxiv.org/abs/2208.08706).

## Model description

This pretrained GAN system consists of a ResNet-style generator and discriminator. During training, stability is controlled by adapting the strength of gradient penalty regularization on-the-fly. The gradient penalty weighting term is contained in *switch.npy*. The generator is conditioned on a latent coordinate system to produce samples of arbitrary length. The latent representations produced by the generator are then passed to a decoder which converts them into waveform audio.
The generator has a context window of about 12 seconds of audio.

### How to use

This pretrained Techno GAN system is automatically downloaded at the first execution of the system. Try Musika [here](https://github.com/marcoppasini/musika)!


## Training data

The Techno GAN system was trained on 1000 hours of music with the *techno* tag from *jamendo.com*.