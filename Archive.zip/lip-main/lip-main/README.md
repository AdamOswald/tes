---
title: Musika
emoji: 🎵
colorFrom: purple
colorTo: blue
sdk: gradio
sdk_version: 3.3.1
app_file: app.py
pinned: false
license: cc-by-4.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
