---
title: Classical Music Generation
emoji: 🎶
colorFrom: pink
colorTo: gray
sdk: gradio
app_file: app.py
pinned: false
---