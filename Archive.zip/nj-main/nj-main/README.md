---
title: Img To Music
emoji: 🌅🎶
colorFrom: green
colorTo: purple
sdk: gradio
sdk_version: 3.16.0
app_file: app.py
pinned: true
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference