---
title: Free MP3-to-Text Using Openai Whisper (Works)
emoji: 👁
colorFrom: green
colorTo: green
sdk: gradio
sdk_version: 3.16.1
app_file: app.py
pinned: false
license: gpl-3.0
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
