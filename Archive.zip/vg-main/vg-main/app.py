import gradio as gr
import whisper

# duplicate this space to run on higher CPU power for the large (very precise and multi-lingual) model to work best

def speech_to_text(uploaded, model_size):
    model = whisper.load_model(model_size)
    source = uploaded if uploaded is not None else ''
    result = model.transcribe(source)
    return f'{result["text"]}'

gr.Interface(
    title="",
    thumbnail="",
    css="""
    footer {visibility: xhidden}
    .gr-prose p{text-align: center;}
    .gr-button {background: black;color: white}
    """,
    description="",
    fn=speech_to_text,
    inputs=[
        gr.Audio(source="upload", type="filepath", label="Upload Audio"), 
        gr.Dropdown(label="Select model size",value="large",choices=["tiny", "base", "small", "medium", "large"])],
    outputs="text").launch(debug = True)