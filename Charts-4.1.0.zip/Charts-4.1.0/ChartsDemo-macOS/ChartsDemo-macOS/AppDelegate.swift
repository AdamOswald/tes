import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate
{
}

